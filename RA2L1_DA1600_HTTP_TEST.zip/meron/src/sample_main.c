/***********************************************************************************************************************
 * Copyright [2020-2021] Renesas Electronics Corporation and/or its affiliates.  All Rights Reserved.
 *
 * This software and documentation are supplied by Renesas Electronics America Inc. and may only be used with products
 * of Renesas Electronics Corp. and its affiliates ("Renesas").  No other uses are authorized.  Renesas products are
 * sold pursuant to Renesas terms and conditions of sale.  Purchasers are solely responsible for the selection and use
 * of Renesas products and Renesas assumes no liability.  No license, express or implied, to any intellectual property
 * right is granted by Renesas. This software is protected under all applicable laws, including copyright laws. Renesas
 * reserves the right to change or discontinue this software and/or this documentation. THE SOFTWARE AND DOCUMENTATION
 * IS DELIVERED TO YOU "AS IS," AND RENESAS MAKES NO REPRESENTATIONS OR WARRANTIES, AND TO THE FULLEST EXTENT
 * PERMISSIBLE UNDER APPLICABLE LAW, DISCLAIMS ALL WARRANTIES, WHETHER EXPLICITLY OR IMPLICITLY, INCLUDING WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT, WITH RESPECT TO THE SOFTWARE OR
 * DOCUMENTATION.  RENESAS SHALL HAVE NO LIABILITY ARISING OUT OF ANY SECURITY VULNERABILITY OR BREACH.  TO THE MAXIMUM
 * EXTENT PERMITTED BY LAW, IN NO EVENT WILL RENESAS BE LIABLE TO YOU IN CONNECTION WITH THE SOFTWARE OR DOCUMENTATION
 * (OR ANY PERSON OR ENTITY CLAIMING RIGHTS DERIVED FROM YOU) FOR ANY LOSS, DAMAGES, OR CLAIMS WHATSOEVER, INCLUDING,
 * WITHOUT LIMITATION, ANY DIRECT, CONSEQUENTIAL, SPECIAL, INDIRECT, PUNITIVE, OR INCIDENTAL DAMAGES; ANY LOST PROFITS,
 * OTHER ECONOMIC DAMAGE, PROPERTY DAMAGE, OR PERSONAL INJURY; AND EVEN IF RENESAS HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH LOSS, DAMAGES, CLAIMS OR COSTS.
 **********************************************************************************************************************/
#include <sample_main.h>
#include "da16200_AT.h"
#include "hal_data.h"
#include "common_utils.h"

/* Set the SSID and password that you want to connect when DA16200 wifi is Station mode */
static char ssid_name[] = {"tplink-56a2"};
static char ssid_pw[] = {"styhii80903"};
/* Set the IP address of the HTTP server */
static char http_server_ip[] = {"192.161.5.2"};
/* Set the content that you need to send to HTTP server */
static char data_to_server[] =
{"This is stream data from DA16200 wifi module"};

volatile uint8_t g_sw1_pressed_flag = 0;
uint8_t led_blink_flag = 0;

static void mcu_init(void);

/************************************************************************************
* Name:       sample_main
* Function:   run sample main of http client
* Parameters: none
* Return:     none
************************************************************************************/
void sample_main(void)
{




    g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_02_PIN_05, BSP_IO_LEVEL_LOW);
    g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_02_PIN_06, BSP_IO_LEVEL_LOW);
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);

    g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_03_PIN_03, BSP_IO_LEVEL_HIGH);
    g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_02_PIN_05, BSP_IO_LEVEL_HIGH);
    g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_02_PIN_06, BSP_IO_LEVEL_HIGH);
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);

    g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_02_PIN_05, BSP_IO_LEVEL_LOW);
    g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_02_PIN_06, BSP_IO_LEVEL_LOW);
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);










    fsp_err_t err;
   // static uint8_t send_cnt = 0;
    mcu_init();                             /* mcu initialization */

    led_blink_flag = 1;                     /* Make red LED blink to indicate wifi setting is making */
    wifi_setting(ssid_name,ssid_pw);  /* wifi setting */
    g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_05_PIN_03, BSP_IO_LEVEL_HIGH);
    /* Turn on Red LED to wifi setting is completed */
             while(1)
             {

                     APP_PRINT("try to send\r\n");
                     err = wifi_http_client_send_data(http_server_ip,data_to_server,10);    /* Send steam data to HTTP server */
                     R_BSP_SoftwareDelay(10,BSP_DELAY_UNITS_SECONDS);
                     if(FSP_SUCCESS == err)
                     {
                         APP_PRINT("HTTP client already post one message, please open a web browser to check it \r\n");
                         g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_05_PIN_05, BSP_IO_LEVEL_HIGH);
                         R_BSP_SoftwareDelay(2,BSP_DELAY_UNITS_SECONDS);
                         g_ioport.p_api->pinWrite (&g_ioport_ctrl, BSP_IO_PORT_05_PIN_05, BSP_IO_LEVEL_LOW);
                     }
                     else
                     {

                         APP_PRINT("not work\r\n");
                     }

                     R_BSP_SoftwareDelay(20,BSP_DELAY_UNITS_SECONDS);
             }


}

/************************************************************************************
* Name:       mcu_init
* Function:   initialize mcu
* Parameters: none
* Return:     none
************************************************************************************/
static void mcu_init(void)
{
    fsp_err_t err;

    /* Key initialization */
  //  err = g_external_sw1.p_api->open(g_external_sw1.p_ctrl, g_external_sw1.p_cfg);
   // err = g_external_sw1.p_api->enable(g_external_sw1.p_ctrl);

    g_timer.p_api->open(g_timer.p_ctrl, g_timer.p_cfg);
    g_timer.p_api->start(g_timer.p_ctrl);

    /* uart initialization */
    err = g_wifi_uart.p_api->open(g_wifi_uart.p_ctrl, g_wifi_uart.p_cfg);

    if(FSP_SUCCESS == err)
    {
        APP_PRINT("mcu Initialize Success! \r\n");
    }
    else
    {
        APP_PRINT("mcu Initialize failed! \r\n");
    }
}

/************************************************************************************
* Name:       sw1_callback
* Function:   button interrupt callback
* Parameters: p_args
* Return:     none
************************************************************************************/


